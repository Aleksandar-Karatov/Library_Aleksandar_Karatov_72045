#pragma once
class Engine
{
public:
	void Run();
};

